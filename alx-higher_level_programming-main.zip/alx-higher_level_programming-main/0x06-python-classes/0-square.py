#!/usr/bin/python3
"""Square class"""


class Square:
    """Empty class Square"""
    pass
