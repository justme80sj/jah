#!/usr/bin/python3
""" Class Rectangle """


class Rectangle:
    """ Empty class Rectangle """
    pass
