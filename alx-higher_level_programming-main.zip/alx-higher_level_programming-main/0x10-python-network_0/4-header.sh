#!/bin/bash
# sends GET req with header var
curl -s -H "X-School-User-Id:98" "$1"
