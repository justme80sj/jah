#!/bin/bash
# sends DELETE
curl -sX 'DELETE' $1
