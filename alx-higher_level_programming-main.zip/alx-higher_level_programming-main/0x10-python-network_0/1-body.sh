#!/bin/bash
# displays body of 200 status code response
curl -sL $1
