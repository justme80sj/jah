$(document).ready(function () {
  $('header').css('color', '#FF0000');
});
