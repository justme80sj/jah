$(document).ready(function () {
  $('#red_header').click(function () {
    $('header').addClass('red');
  });
});
