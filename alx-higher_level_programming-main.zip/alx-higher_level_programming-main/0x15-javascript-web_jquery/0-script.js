document.querySelector('header').style.color = '#FF0000';
