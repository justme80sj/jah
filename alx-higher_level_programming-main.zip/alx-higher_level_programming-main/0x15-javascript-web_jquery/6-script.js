$('DIV#update_header').click(() => {
  $('header').text('New Header!!!');
});
