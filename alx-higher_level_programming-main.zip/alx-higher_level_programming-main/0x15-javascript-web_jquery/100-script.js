document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('header').style.color = '#FF0000';
});
