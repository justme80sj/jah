# SQL - More queries
Project done during **Full Stack Software Engineering studies** at **Alx School**. It aims to learn about how to create a new user, manage privileges for a user, `PRIMARY KEY`, `FOREIGN KEY`, constraints, subqueries, `JOIN` and `UNION` with **MySQL**.

## Technologies
* `MySQL 5.7` (version 5.7.8-rc)
* Tested on Ubuntu 20.04 LTS