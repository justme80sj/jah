-- Script that creates a table
-- Query to create the table 'force_name' in MySQL server
CREATE TABLE IF NOT EXISTS force_name (
       id INT,
       name VARCHAR(256) NOT NULL);
