-- Script that creates a table
-- Query to create the table 'id_not_null' in MySQL server
CREATE TABLE IF NOT EXISTS id_not_null (
       id INT DEFAULT 1,
       name VARCHAR(256));
