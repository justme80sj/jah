-- Script that lists all privileges of the MySQL users
-- Query to list all privileges (GRANT) of the MySQL users
SHOW GRANTS FOR 'user_0d_1'@'localhost';
SHOW GRANTS FOR 'user_0d_2'@'localhost';
