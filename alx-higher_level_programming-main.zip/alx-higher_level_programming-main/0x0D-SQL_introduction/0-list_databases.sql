-- Displays all databases
-- Query to display databases
SHOW DATABASES;
