-- Cheating is bad
-- updates the score of Bob to 10
UPDATE second_table SET score=10 WHERE name="Bob";
