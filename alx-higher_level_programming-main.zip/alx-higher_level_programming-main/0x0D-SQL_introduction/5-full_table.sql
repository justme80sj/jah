-- Prints the full description of the table first_table from the database
-- Query to print full description of a table
SHOW CREATE TABLE first_table;
