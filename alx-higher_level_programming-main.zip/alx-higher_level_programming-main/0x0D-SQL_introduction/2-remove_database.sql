-- Deletes a database
-- Query to delete the database hbtn_0c_0 in MySQL server
DROP DATABASE IF EXISTS hbtn_0c_0;
