-- List by best
-- Show score ordered and name from second_table
SELECT score, name FROM second_table ORDER BY score DESC, name;
