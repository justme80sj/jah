-- Score too low
-- removes all records with a score <= 5
DELETE FROM second_table WHERE score <= 5;
