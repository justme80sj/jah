-- Average
-- computes the score average of all records
SELECT AVG(score) AS average FROM second_table;
