-- Lists all the tables of a database
-- Query to list all tables of a database
SHOW TABLES;
