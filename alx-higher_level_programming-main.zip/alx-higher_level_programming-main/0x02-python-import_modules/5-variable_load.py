#!/usr/bin/python3
if __name__ == "__main__":
    from variable_load_5 import a
    print(a)
