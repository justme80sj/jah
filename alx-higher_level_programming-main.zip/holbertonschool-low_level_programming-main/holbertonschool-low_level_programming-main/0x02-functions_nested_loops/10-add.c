#include "holberton.h"
/**
 * add - a function that adds two integers and returns the result
 * @one: first number input
 * @two: second number input
 * Return: one + two
 */
int add(int one, int two)
{
	return (one + two);
}
