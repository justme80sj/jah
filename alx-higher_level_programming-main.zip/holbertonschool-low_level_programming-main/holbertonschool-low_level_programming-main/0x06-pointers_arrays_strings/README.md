0x05. C - More pointers, arrays and strings
Description
What you should learn from this project:

Everything from 0x04. C - Pointers, arrays and strings
0. strcat
Write a function that concatenates two strings.
1. strncat
Write a function that concatenates two strings. With n bytes.
2. strncpy
Write a function that copies a string.
3. strcmp
Write a function that compares two strings.
4. I am a kind of paranoid in reverse. I suspect people of plotting to make me happy
Write a function that reverses the content of an array of integers.
5. Always look up
Write a function that changes all lowercase letters of a string to uppercase.
6. Expect the best. Prepare for the worst. Capitalize on what comes
Write a function that capitalizes all words of a string.
7. Mozart composed his music not for the elite, but for everybody
Write a function that encodes a string into 1337.
8. rot13
Write a function that encodes a string using rot13.