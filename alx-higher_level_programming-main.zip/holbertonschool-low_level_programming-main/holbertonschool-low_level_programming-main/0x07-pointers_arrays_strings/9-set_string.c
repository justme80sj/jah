#include "holberton.h"

/**
 * set_string - Entry point
 * @s: input
 * @to: input
 * Return: Always 0 (Success)
 */
void set_string(char **s, char *to)
{
	*s = to;
}
